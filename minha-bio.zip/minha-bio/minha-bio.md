# Somente eu...
***
Meu nome é Evelyn, tenho 33 anos, hoje sou casada e mãe. Ainda é dificil falar de mim mesma, estou aprendo na terapia _rs_. Gosto de estar em familia, gosto de jogos de tabuleiro, filmes, séries e comer, eu amo comer bem (mas agora funcional, por conta disso).
 
Trabalhei por quase 10 anos em uma franquia de locação de equipamentos, e ao longo desses anos, cargos de
liderança/gestão acabaram chegando até mim. E aproveitei essas oportunidades, e é claro nesse
momento, é necessário ser humilde, buscar conhecimento, entender o quanto pode melhorar e também reconhecer seus erros.

Decidi sair do meu emprego para focar na minha saúde, e comecei a pensar em uma nova carreira. Como gosto de estudar aproveitei a oportunidade de estudar e fazer uma transição para algo que me sinto mais a vontade de trabalhar. 